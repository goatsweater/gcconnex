
#didyouknow-settings table{
	margin: 16px;
}
#didyouknow-settings table tr td{
	background-color: #dddddd;
	border: 4px solid #aaaaaa;
	padding: 4px;
	vertical-align: middle;
	text-align: right;
}
