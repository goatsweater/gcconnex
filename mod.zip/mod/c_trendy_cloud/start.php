<?php

elgg_register_event_handler('init', 'system', 'c_trendy_cloud_init');


function c_trendy_cloud_init() {

}
