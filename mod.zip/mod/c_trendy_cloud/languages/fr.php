<?php

$french = array(
	'trendy:title' => 'Le Trendy Cloud',
);

add_translation('fr', $french);
