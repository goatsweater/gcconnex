<?php

$english = array(
	'trendy:title' => 'Trendy Cloud',
);

add_translation('en', $english);
