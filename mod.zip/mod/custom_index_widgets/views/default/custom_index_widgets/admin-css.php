
/*GCChange - added this so that newest members display as a grid instead of a huge list*/
div.elgg-widget-content ul.elgg-gallery li.elgg-item {
	float: left;
}
