<?php 
  
	include elgg_get_plugins_path() . 'simplepie/views/default/widgets/feed_reader/content.php';
	
	//$body = elgg_view("simplepie/widgets/feed_reader/content", $vars);
	//echo $body;  
  
?>        
