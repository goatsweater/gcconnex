<ul>
	<li>I am <a href="?abc123">the a tag</a> example</li>
	<li>I am <abbr title="test">the abbr tag</abbr> example</li>
	<li>I am <acronym>the acronym tag</acronym> example</li>
	<li>I am <b>the b tag</b> example</li>
	<li>I am <code>the code tag</code> example</li>
	<li>I am <del>the del tag</del> example</li>
	<li>I am <em>the em tag</em> example</li>
	<li>I am <i>the i tag</i> example</li>
	<li>I am <strong>the strong tag</strong> example</li>
</ul>
<blockquote><p>Paragraph inside Blockquote: <?php echo $ipsum; ?></p></blockquote>
<pre>
	<strong>Preformated:</strong>Testing one row
	and another
</pre>
