<?php

$english = array(
	'grp_just:member_info' => 'GCconnex Member Information',
	'grp_just:group_info' => 'GCconnex Group Information',
	'grp_just:justification' => 'Application',
	'grp_just:submit_app' => 'Submit Application',
	'grp_just:review_app' => 'Application',
	'grp_just:app_sent' => 'Application in evaluation',
	'grp_just:apply' => 'Request Membership',
	'grp_just:notice' => 'Please note that this is a closed group and the group administrator must approve your request to join. In the space below, briefly provide the reason(s) why you would like to be added to this closed group for the administrator to review in considering your request.',
);

add_translation("en",$english);
