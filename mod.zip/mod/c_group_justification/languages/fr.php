<?php

$french = array(
	'grp_just:member_info' => 'Information de la utilisateur',
	'grp_just:group_info' => 'Information de la groupe',
	'grp_just:justification' => 'Application',
	'grp_just:submit_app' => 'Transmission de votre demande',
	'grp_just:review_app' => 'Application',
	'grp_just:app_sent' => 'Application en évaluation',
	'grp_just:apply' => 'Demander de devenir membre',
	'grp_just:notice' => 'Veuillez noter que ce groupe est un groupe fermé. L’administrateur doit approuver votre demande d’adhésion. Afin de faciliter la tâche de l’administrateur, veuillez expliquer brièvement pourquoi vous voulez vous joindre à ce groupe fermé dans l’espace ci-après.',
);

add_translation("fr",$french);