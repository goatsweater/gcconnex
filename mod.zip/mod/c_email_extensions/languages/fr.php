<?php

$french = array(
	'c_ext:id' => 'xxxxxxx',
	'c_ext:ext' => 'xxxxxxx',
	'c_ext:dept' => 'xxxxxxx',
	'c_ext:add_new_ext' => 'xxxxxxx',
	'c_ext:add' => 'xxxxxxx',
	'c_ext:delete' => 'xxxxxxxx',
);

add_translation("fr",$french);