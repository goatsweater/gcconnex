<?php

// need a function that


?>

<!-- HTML -->

<form>
<!-- banner style selection -->
<b> Banner Style </b><br />

	<input type="radio" name="banner_style" value="marquee"> scrolling banner <br />
	<input type="radio" name="banner_style" value="stationary"> static banner <br />

<br />

<!-- depending on the selected banner style selection, give user more option -->
<b> Font Style </b><br />


<br />

<!-- let user put in a message as the notice -->
<b> Notice Message </b><br />
	<textarea style="width:100%;" rows="4" cols="500">this will be prepopulated...</textarea>

<br /><br />

<b> Preview of HTML code snippet that will be injected into the page </b><br />
<pre>System.out.println("Hello World!")</pre>

<br />

</form>